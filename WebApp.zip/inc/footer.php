<footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
        Versi xx.xxxxxx.xx
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; Sistem IoT <a href="https://websitesaya.com">Website</a>.</strong> All rights reserved.
</footer>